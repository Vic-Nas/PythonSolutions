from setuptools import setup, find_packages

setup(
    name="vicutils",             # package name
    version="0.3",
    packages=find_packages(),    # finds vicutils folder automatically
    install_requires=[],         # optional, for dependencies
)